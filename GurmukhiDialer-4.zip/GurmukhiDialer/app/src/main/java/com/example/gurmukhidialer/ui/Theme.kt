package com.example.gurmukhidialer.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

// Soft lavender-blue palette. Tweak colors here; the whole app follows.
private val LightColors = lightColorScheme(
    primary = Color(0xFF4A66D6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE3FA),
    onPrimaryContainer = Color(0xFF1D2B63),
    secondaryContainer = Color(0xFFD5DCF5),
    onSecondaryContainer = Color(0xFF1D2B63),
    background = Color(0xFFF5F6FB),
    onBackground = Color(0xFF2B3557),
    surface = Color(0xFFE8EEF8), // bottom bar
    onSurface = Color(0xFF2B3557),
    surfaceVariant = Color(0xFFDDE2F3), // key circles
    onSurfaceVariant = Color(0xFF667096),
    outlineVariant = Color(0xFFD5D9E8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6FA8FF),
    onPrimary = Color(0xFF06223F),
    primaryContainer = Color(0xFF1F3A66),
    onPrimaryContainer = Color(0xFFD6E6FF),
    secondaryContainer = Color(0xFF1F3A66),
    onSecondaryContainer = Color(0xFFD6E6FF),
    background = Color(0xFF0B0D12),
    onBackground = Color(0xFFF2F4F8),
    surface = Color(0xFF1A2030), // bottom bar
    onSurface = Color(0xFFF2F4F8),
    surfaceVariant = Color(0xFF313846), // key circles
    onSurfaceVariant = Color(0xFFA3AAB8),
    outlineVariant = Color(0xFF2A303C),
)

@Composable
fun GurmukhiDialerTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = scheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
            content = content,
        )
    }
}
