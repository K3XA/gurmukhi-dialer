package com.example.gurmukhidialer.telecom

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.gurmukhidialer.ui.InCallActivity

@Suppress("DEPRECATION")
class DialerInCallService : InCallService() {

    private val stateCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_RINGING) {
                NotificationManagerCompat.from(this@DialerInCallService).cancel(NOTIFICATION_ID)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Incoming calls", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onDestroy() {
        if (CallManager.service === this) CallManager.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        CallManager.add(call)
        call.registerCallback(stateCallback)
        if (call.state == Call.STATE_RINGING) showIncoming(call) else startActivity(callIntent())
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(stateCallback)
        CallManager.remove(call)
        NotificationManagerCompat.from(this).cancel(NOTIFICATION_ID)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallManager.onAudioState(audioState)
    }

    private fun callIntent() =
        Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @SuppressLint("MissingPermission")
    private fun showIncoming(call: Call) {
        val pending = PendingIntent.getActivity(
            this, 0, callIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming call")
            .setContentText(call.details.handle?.schemeSpecificPart.orEmpty())
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setContentIntent(pending)
            .setFullScreenIntent(pending, true)
            .build()
        NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification)
    }

    private companion object {
        const val CHANNEL_ID = "incoming_calls"
        const val NOTIFICATION_ID = 1
    }
}
