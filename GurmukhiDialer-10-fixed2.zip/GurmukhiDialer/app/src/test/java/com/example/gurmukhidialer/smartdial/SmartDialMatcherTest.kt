package com.example.gurmukhidialer.smartdial

import com.example.gurmukhidialer.data.Contact
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartDialMatcherTest {
    private fun index(vararg names: String) = names.mapIndexed { i, n ->
        SmartDialMatcher.index(Contact(i.toLong(), n, "98${i}0000000"))
    }

    private fun names(query: String, vararg contacts: String) =
        SmartDialMatcher.search(query, index(*contacts)).map { it.contact.name }

    @Test fun gurmukhiKeysIgnoreVowelSigns() {
        assertEquals(listOf("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ"), names("387", "ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ", "ਹਰਜੀਤ ਕੌਰ"))
    }

    @Test fun latinDigitsFindGurmukhiNames() {
        assertEquals(listOf("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ"), names("4877", "ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ", "ਹਰਜੀਤ ਕੌਰ"))
    }

    @Test fun latinNamesStillWork() {
        assertEquals(listOf("Gurpreet Singh"), names("4877", "Gurpreet Singh", "Harjeet Kaur"))
    }

    @Test fun surnameMatchesAtAnyWordStart() {
        assertEquals(listOf("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ"), names("23", "ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ", "ਹਰਜੀਤ ਕੌਰ"))
        assertEquals(listOf("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ"), names("746", "ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ", "ਹਰਜੀਤ ਕੌਰ"))
    }

    @Test fun highlightKeepsConjunctTogether() {
        val hit = SmartDialMatcher.search("387", index("ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ")).single()
        assertEquals("ਗੁਰਪ੍", "ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ".substring(hit.highlight!!.first, hit.highlight!!.last + 1))
    }

    @Test fun numberDigitsMatchToo() {
        val r = SmartDialMatcher.search("9800", index("Test"))
        assertTrue(r.single().highlight == null)
    }

    @Test fun frequentCallsRankHigher() {
        val idx = index("Gurpal A", "Gurpal B")
        val recency = mapOf(PhoneKey.of(idx[1].contact.number) to 5)
        assertEquals("Gurpal B", SmartDialMatcher.search("4877", idx, recency).first().contact.name)
    }
}
