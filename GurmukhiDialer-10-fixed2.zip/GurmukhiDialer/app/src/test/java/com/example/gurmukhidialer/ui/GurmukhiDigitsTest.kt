package com.example.gurmukhidialer.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class GurmukhiDigitsTest {
    @Test fun convertsDigitsAndKeepsSymbols() {
        assertEquals("੨੩੨", "232".toGurmukhiDigits())
        assertEquals("+੯੧ ੭੫੮੯੪ #*", "+91 75894 #*".toGurmukhiDigits())
    }
}
