package com.example.gurmukhidialer.smartdial

/** Gurmukhi letters grouped onto keys 2-8 in varnamala order. Key 9 has no letters. */
object GurmukhiKeys {
    val groups: Map<Char, String> = mapOf(
        '2' to "ੳਅੲਸਹ",
        '3' to "ਕਖਗਘਙ",
        '4' to "ਚਛਜਝਞ",
        '5' to "ਟਠਡਢਣ",
        '6' to "ਤਥਦਧਨ",
        '7' to "ਪਫਬਭਮ",
        '8' to "ਯਰਲਵੜ",
    )

    private val letterToDigit: Map<Char, Char> = buildMap {
        for ((digit, letters) in groups) for (l in letters) put(l, digit)
        // Precomposed nukta letters share the key of their base letter.
        put('\u0A36', '2') // ਸ਼
        put('\u0A59', '3') // ਖ਼
        put('\u0A5A', '3') // ਗ਼
        put('\u0A5B', '4') // ਜ਼
        put('\u0A5E', '7') // ਫ਼
        put('\u0A33', '8') // ਲ਼
        // Independent vowels (ਆ ਇ ਈ ਉ ਊ ਏ ਐ ਓ ਔ) sit on the ਅ ੳ ੲ key.
        for (c in '\u0A06'..'\u0A14') put(c, '2')
    }

    fun digitOf(c: Char): Char? = letterToDigit[c]

    /** Vowel signs, nasal marks, nukta, virama and similar combining marks. */
    fun isMark(c: Char): Boolean {
        val n = c.code
        return n in 0x0A01..0x0A03 || n in 0x0A3C..0x0A4D ||
            n == 0x0A51 || n == 0x0A70 || n == 0x0A71 || n == 0x0A75
    }

    /** Key digits for a Gurmukhi string, ignoring vowel signs and marks. */
    fun skeleton(text: String): String = buildString {
        for (c in text) digitOf(c)?.let { append(it) }
    }

    fun label(digit: Char): String = groups[digit]?.toList()?.joinToString(" ") ?: ""
}

object LatinT9 {
    private val groups = mapOf(
        '2' to "abc", '3' to "def", '4' to "ghi", '5' to "jkl",
        '6' to "mno", '7' to "pqrs", '8' to "tuv", '9' to "wxyz",
    )
    private val letterToDigit: Map<Char, Char> = buildMap {
        for ((digit, letters) in groups) for (l in letters) put(l, digit)
    }

    fun digitOf(c: Char): Char? = letterToDigit[c.lowercaseChar()]

    fun encode(text: String): String = buildString {
        for (c in text) digitOf(c)?.let { append(it) }
    }

    fun label(digit: Char): String = groups[digit]?.uppercase() ?: ""
}

/** Last 10 digits of a number, used to match call-log numbers to contacts. */
object PhoneKey {
    fun of(number: String): String = number.filter { it.isDigit() }.takeLast(10)
}
