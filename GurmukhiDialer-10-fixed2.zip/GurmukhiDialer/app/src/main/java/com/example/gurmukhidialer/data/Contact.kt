package com.example.gurmukhidialer.data

data class Contact(val id: Long, val name: String, val number: String)
