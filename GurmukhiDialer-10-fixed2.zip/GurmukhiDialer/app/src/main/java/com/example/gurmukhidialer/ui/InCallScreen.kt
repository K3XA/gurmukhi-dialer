package com.example.gurmukhidialer.ui

import android.telecom.Call
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gurmukhidialer.data.ContactsRepository
import com.example.gurmukhidialer.telecom.CallManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun InCallScreen(onFinished: () -> Unit) {
    val calls by CallManager.calls.collectAsState()
    val audio by CallManager.audio.collectAsState()
    val primary = calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.firstOrNull()
    val number = primary?.number.orEmpty()

    val context = LocalContext.current
    var name by remember(number) { mutableStateOf<String?>(null) }
    LaunchedEffect(number) {
        name = withContext(Dispatchers.IO) { ContactsRepository(context).lookupName(number) }
    }
    LaunchedEffect(calls.isEmpty()) { if (calls.isEmpty()) onFinished() }

    if (primary == null) return

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(name ?: number.toGurmukhiDigits().ifEmpty { "ਅਣਜਾਣ" }, fontSize = 32.sp)
            if (name != null) {
                Text(number.toGurmukhiDigits(), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            Text(stateLabel(primary.state), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (primary.state == Call.STATE_RINGING) {
            Row(Modifier.fillMaxWidth().padding(bottom = 32.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(
                    onClick = { CallManager.decline(primary.call) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("ਰੱਦ ਕਰੋ") }
                Button(
                    onClick = { CallManager.answer(primary.call) },
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF2E7D32)),
                ) { Text("ਕਾਲ ਚੁੱਕੋ") }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(bottom = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Toggle("ਮਿਊਟ", audio.muted) { CallManager.setMuted(!audio.muted) }
                    Toggle("ਸਪੀਕਰ", audio.speaker) { CallManager.setSpeaker(!audio.speaker) }
                    Toggle("ਹੋਲਡ", primary.state == Call.STATE_HOLDING) { CallManager.toggleHold(primary.call) }
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { CallManager.hangUp(primary.call) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("ਕਾਲ ਖਤਮ ਕਰੋ") }
            }
        }
    }
}

@Composable
private fun Toggle(label: String, on: Boolean, onClick: () -> Unit) {
    if (on) FilledTonalButton(onClick = onClick) { Text(label) }
    else OutlinedButton(onClick = onClick) { Text(label) }
}

private fun stateLabel(state: Int) = when (state) {
    Call.STATE_DIALING, Call.STATE_CONNECTING -> "ਕਾਲ ਕਰ ਰਿਹਾ ਹੈ…"
    Call.STATE_RINGING -> "ਆਉਣ ਵਾਲੀ ਕਾਲ"
    Call.STATE_ACTIVE -> "ਜੁੜਿਆ ਹੋਇਆ"
    Call.STATE_HOLDING -> "ਹੋਲਡ ਉੱਤੇ"
    Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "ਕਾਲ ਖਤਮ ਹੋ ਰਹੀ ਹੈ…"
    else -> ""
}
