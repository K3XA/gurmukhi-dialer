package com.example.gurmukhidialer.ui

private const val GURMUKHI_DIGITS = "੦੧੨੩੪੫੬੭੮੯"

/** Shows 0-9 as Gurmukhi numerals. Display only; dialing still uses plain digits. */
fun String.toGurmukhiDigits(): String = buildString {
    for (c in this@toGurmukhiDigits) append(if (c in '0'..'9') GURMUKHI_DIGITS[c - '0'] else c)
}

/** "5 ਮਿੰਟ ਪਹਿਲਾਂ" style relative time, in Gurmukhi. */
fun timeAgoGurmukhi(millis: Long): String {
    val minutes = (System.currentTimeMillis() - millis) / 60000
    return when {
        minutes < 1 -> "ਹੁਣੇ"
        minutes < 60 -> "${minutes} ਮਿੰਟ ਪਹਿਲਾਂ".toGurmukhiDigits()
        minutes < 60 * 24 -> "${minutes / 60} ਘੰਟੇ ਪਹਿਲਾਂ".toGurmukhiDigits()
        else -> "${minutes / (60 * 24)} ਦਿਨ ਪਹਿਲਾਂ".toGurmukhiDigits()
    }
}
