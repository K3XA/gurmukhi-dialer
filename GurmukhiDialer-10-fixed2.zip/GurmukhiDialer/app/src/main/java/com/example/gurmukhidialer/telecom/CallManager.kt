package com.example.gurmukhidialer.telecom

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CallUi(val call: Call, val number: String, val state: Int)
data class AudioUi(val muted: Boolean = false, val speaker: Boolean = false)

@Suppress("DEPRECATION")
object CallManager {
    private val active = mutableListOf<Call>()
    private val _calls = MutableStateFlow<List<CallUi>>(emptyList())
    val calls: StateFlow<List<CallUi>> = _calls.asStateFlow()

    private val _audio = MutableStateFlow(AudioUi())
    val audio: StateFlow<AudioUi> = _audio.asStateFlow()

    var service: InCallService? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = publish()
        override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
    }

    fun add(call: Call) {
        active += call
        call.registerCallback(callback)
        publish()
    }

    fun remove(call: Call) {
        call.unregisterCallback(callback)
        active -= call
        publish()
    }

    private fun publish() {
        _calls.value = active.map {
            CallUi(it, it.details.handle?.schemeSpecificPart.orEmpty(), it.state)
        }
    }

    fun answer(c: Call) = c.answer(VideoProfile.STATE_AUDIO_ONLY)
    fun decline(c: Call) = c.reject(false, null)
    fun hangUp(c: Call) = c.disconnect()
    fun toggleHold(c: Call) = if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()

    fun setMuted(muted: Boolean) {
        service?.setMuted(muted)
    }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(
            if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE
        )
    }

    fun onAudioState(s: CallAudioState) {
        _audio.value = AudioUi(s.isMuted, s.route == CallAudioState.ROUTE_SPEAKER)
    }
}
