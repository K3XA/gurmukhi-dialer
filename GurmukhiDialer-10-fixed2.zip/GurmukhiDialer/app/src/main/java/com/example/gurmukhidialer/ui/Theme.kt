package com.example.gurmukhidialer.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

// Soft lavender-blue palette. Tweak colors here; the whole app follows.
private val LightColors = lightColorScheme(
    primary = Color(0xFF6C63FF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE1DEFF),
    onPrimaryContainer = Color(0xFF251E63),
    secondaryContainer = Color(0xFFE1DEFF),
    onSecondaryContainer = Color(0xFF251E63),
    background = Color(0xFFF7F7FC),
    onBackground = Color(0xFF23253A),
    surface = Color(0xFFFFFFFF), // bottom bar / cards
    onSurface = Color(0xFF23253A),
    surfaceVariant = Color(0xFFEDEDF7), // key circles
    onSurfaceVariant = Color(0xFF6E7191),
    outlineVariant = Color(0xFFE4E4F0),
)

/** Purple-to-blue gradient used on the call button and the "enter number" surface. */
val GradientStart = Color(0xFF6C63FF)
val GradientEnd = Color(0xFF4A9DFF)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8B84FF),
    onPrimary = Color(0xFF120B3F),
    primaryContainer = Color(0xFF241C4F),
    onPrimaryContainer = Color(0xFFE1DEFF),
    secondaryContainer = Color(0xFF241C4F),
    onSecondaryContainer = Color(0xFFE1DEFF),
    background = Color(0xFF0B0C18),
    onBackground = Color(0xFFEDEDF7),
    surface = Color(0xFF141527), // bottom bar / cards
    onSurface = Color(0xFFEDEDF7),
    surfaceVariant = Color(0xFF1F2038), // key circles
    onSurfaceVariant = Color(0xFF9A9CC0),
    outlineVariant = Color(0xFF252645),
)

private const val PREFS_NAME = "gurmukhi_dialer_prefs"
private const val KEY_DARK_OVERRIDE = "dark_override"

/** null = follow the system setting; true/false = the user's manual choice from the toggle icon.
 *  The choice is saved to SharedPreferences so it survives closing the app. */
object ThemeController {
    var darkOverride by mutableStateOf<Boolean?>(null)
        private set
    private var loaded = false

    fun loadIfNeeded(context: Context) {
        if (loaded) return
        loaded = true
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        darkOverride = if (prefs.contains(KEY_DARK_OVERRIDE)) prefs.getBoolean(KEY_DARK_OVERRIDE, false) else null
    }

    fun setDarkOverride(context: Context, value: Boolean) {
        darkOverride = value
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DARK_OVERRIDE, value).apply()
    }
}

@Composable
fun isAppInDarkTheme(): Boolean = ThemeController.darkOverride ?: isSystemInDarkTheme()

@Composable
fun GurmukhiDialerTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { ThemeController.loadIfNeeded(context) }
    val scheme = if (isAppInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = scheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
            content = content,
        )
    }
}
