package com.example.gurmukhidialer.smartdial

/**
 * Rough Punjabi romanizer so "4877" (g-u-r-p) finds ਗੁਰਪ੍ਰੀਤ.
 * Heuristic: a consonant with no vowel sign gets an "a" only when the word
 * has no vowel yet and the consonant isn't last (ਹਰਜੀਤ -> harjeet, ਗੁਰਪ੍ਰੀਤ -> gurpreet).
 */
object GurmukhiRomanizer {
    private val consonants = mapOf(
        'ਕ' to "k", 'ਖ' to "kh", 'ਗ' to "g", 'ਘ' to "gh", 'ਙ' to "ng",
        'ਚ' to "ch", 'ਛ' to "chh", 'ਜ' to "j", 'ਝ' to "jh", 'ਞ' to "n",
        'ਟ' to "t", 'ਠ' to "th", 'ਡ' to "d", 'ਢ' to "dh", 'ਣ' to "n",
        'ਤ' to "t", 'ਥ' to "th", 'ਦ' to "d", 'ਧ' to "dh", 'ਨ' to "n",
        'ਪ' to "p", 'ਫ' to "f", 'ਬ' to "b", 'ਭ' to "bh", 'ਮ' to "m",
        'ਯ' to "y", 'ਰ' to "r", 'ਲ' to "l", 'ਵ' to "v", 'ੜ' to "r",
        'ਸ' to "s", 'ਹ' to "h",
        '\u0A36' to "sh", '\u0A59' to "kh", '\u0A5A' to "g",
        '\u0A5B' to "z", '\u0A5E' to "f", '\u0A33' to "l",
    )
    private val vowelSigns = mapOf(
        'ਾ' to "a", 'ਿ' to "i", 'ੀ' to "ee", 'ੁ' to "u", 'ੂ' to "oo",
        'ੇ' to "e", 'ੈ' to "ai", 'ੋ' to "o", 'ੌ' to "au",
        'ੰ' to "n", 'ਂ' to "n",
    )
    private val independent = mapOf(
        'ਅ' to "a", 'ਆ' to "aa", 'ਇ' to "i", 'ਈ' to "ee", 'ਉ' to "u", 'ਊ' to "oo",
        'ਏ' to "e", 'ਐ' to "ai", 'ਓ' to "o", 'ਔ' to "au", 'ੳ' to "u", 'ੲ' to "i",
    )

    fun romanize(word: String): String {
        val sb = StringBuilder()
        var hasVowel = false
        for (i in word.indices) {
            val c = word[i]
            val next = word.getOrNull(i + 1)
            val independentVowel = independent[c]
            val consonant = consonants[c]
            val sign = vowelSigns[c]
            when {
                independentVowel != null -> {
                    sb.append(independentVowel)
                    hasVowel = true
                }
                consonant != null -> {
                    sb.append(consonant)
                    val hasSign = next != null && next.code in 0x0A3E..0x0A4C
                    val conjunct = next == '\u0A4D'
                    if (!hasSign && !conjunct && !hasVowel && next != null) {
                        sb.append('a')
                        hasVowel = true
                    }
                }
                sign != null -> {
                    sb.append(sign)
                    if (c.code in 0x0A3E..0x0A4C) hasVowel = true
                }
            }
        }
        return sb.toString()
    }
}
