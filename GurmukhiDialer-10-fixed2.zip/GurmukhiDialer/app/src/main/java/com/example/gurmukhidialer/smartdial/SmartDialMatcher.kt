package com.example.gurmukhidialer.smartdial

import com.example.gurmukhidialer.data.Contact

data class Word(
    val start: Int,
    val text: String,
    val gurmukhiKey: String,
    val latinKey: String,
    val isGurmukhi: Boolean,
)

data class IndexedContact(val contact: Contact, val words: List<Word>, val numberDigits: String)

/** [highlight] is the matched span of the contact name, or null for a number match. */
data class Match(val contact: Contact, val highlight: IntRange?, val score: Int)

object SmartDialMatcher {

    private data class Hit(val rank: Int, val range: IntRange?)

    fun index(contact: Contact): IndexedContact {
        val words = Regex("\\S+").findAll(contact.name).map { m ->
            val text = m.value
            val gKey = GurmukhiKeys.skeleton(text)
            val isGurmukhi = gKey.isNotEmpty()
            val latin = LatinT9.encode(if (isGurmukhi) GurmukhiRomanizer.romanize(text) else text)
            Word(m.range.first, text, gKey, latin, isGurmukhi)
        }.toList()
        return IndexedContact(contact, words, contact.number.filter { it.isDigit() })
    }

    /** [query] is the digits typed on the keypad. Ranked by match quality, then call frequency. */
    fun search(
        query: String,
        index: List<IndexedContact>,
        recency: Map<String, Int> = emptyMap(),
    ): List<Match> {
        if (query.isEmpty()) return emptyList()
        return index.mapNotNull { ic ->
            val hit = match(query, ic) ?: return@mapNotNull null
            val calls = recency[PhoneKey.of(ic.contact.number)] ?: 0
            Match(ic.contact, hit.range, hit.rank * 100 + minOf(calls, 99))
        }.sortedWith(compareByDescending<Match> { it.score }.thenBy { it.contact.name })
    }

    private fun match(q: String, ic: IndexedContact): Hit? {
        val hits = ArrayList<Hit>()
        ic.words.forEachIndexed { i, w ->
            val first = i == 0
            if (w.gurmukhiKey.startsWith(q)) {
                hits += Hit(if (first) 100 else 80, w.start until w.start + gurmukhiEnd(w.text, q.length))
            } else if (w.latinKey.startsWith(q)) {
                val end = if (w.isGurmukhi) w.text.length else latinEnd(w.text, q.length)
                hits += Hit(if (first) 90 else 70, w.start until w.start + end)
            }
        }
        if (ic.words.size > 1) {
            val fullG = ic.words.joinToString("") { it.gurmukhiKey }
            val fullL = ic.words.joinToString("") { it.latinKey }
            if (fullG.startsWith(q)) hits += Hit(60, covered(ic.words, q.length, true))
            else if (fullL.startsWith(q)) hits += Hit(50, covered(ic.words, q.length, false))
        }
        if (ic.numberDigits.contains(q)) hits += Hit(20, null)
        return hits.maxByOrNull { it.rank }
    }

    /** End index (exclusive) after [count] key-producing letters, keeping trailing vowel signs. */
    private fun gurmukhiEnd(text: String, count: Int): Int {
        var seen = 0
        var i = 0
        while (i < text.length) {
            if (GurmukhiKeys.digitOf(text[i]) != null) {
                seen++
                if (seen == count) {
                    i++
                    break
                }
            }
            i++
        }
        while (i < text.length && GurmukhiKeys.isMark(text[i])) i++
        return i
    }

    private fun latinEnd(text: String, count: Int): Int {
        var seen = 0
        for ((i, c) in text.withIndex()) {
            if (LatinT9.digitOf(c) != null) {
                seen++
                if (seen == count) return i + 1
            }
        }
        return text.length
    }

    private fun covered(words: List<Word>, len: Int, gurmukhi: Boolean): IntRange {
        var total = 0
        for (w in words) {
            total += if (gurmukhi) w.gurmukhiKey.length else w.latinKey.length
            if (total >= len) return words.first().start until w.start + w.text.length
        }
        return words.first().start until words.last().start + words.last().text.length
    }
}
