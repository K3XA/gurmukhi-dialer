# Gurmukhi Dialer

Open this folder in Android Studio (Ladybug or newer), let Gradle sync, run on a device with a SIM.
On first launch, grant the permissions and accept the "default phone app" prompt.

Run the smart dial tests: `./gradlew :app:testDebugUnitTest` (or right-click `SmartDialMatcherTest` in Android Studio).

## Layout
- `smartdial/` pure Kotlin: key groups, romanizer, matcher (unit tested)
- `data/` contacts and call-log queries
- `telecom/` `InCallService` and call state
- `ui/` Compose dialer and in-call screens

## Not built yet
Recents, Favorites, Contacts tabs; voicemail; DTMF, add/merge call; call blocking and spam screening; dual-SIM picker.
