package com.example.gurmukhidialer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gurmukhidialer.smartdial.GurmukhiKeys
import com.example.gurmukhidialer.smartdial.Match

private val KEYS = "123456789*0#".toList()
private const val GURMUKHI_DIGITS = "੦੧੨੩੪੫੬੭੮੯"
private val TABS = listOf("ਮਨਪਸੰਦ", "ਹਾਲੀਆ", "ਕੀਪੈਡ", "ਸੰਪਰਕ")
private const val KEYPAD_TAB = 2
private val CallGreen = Color(0xFF2E9E5B)
private val FavoriteOrange = Color(0xFFF2A03D)

@Composable
fun DialerScreen(vm: DialerViewModel, onCall: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(KEYPAD_TAB) }
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == KEYPAD_TAB) {
                KeypadTab(vm, onCall)
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "${TABS[tab]} – ਜਲਦੀ ਆ ਰਿਹਾ ਹੈ",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        BottomNav(tab) { tab = it }
    }
}

@Composable
private fun Header() {
    Column {
        Text(
            "ਗੁਰਮੁਖੀ ਡਾਇਲਰ",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
        )
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun KeypadTab(vm: DialerViewModel, onCall: (String) -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize()) {
        Text(
            text = vm.digits.ifEmpty { "ਨੰਬਰ ਦਰਜ ਕਰੋ" },
            fontSize = 34.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (vm.digits.isEmpty()) muted.copy(alpha = 0.7f)
            else MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                vm.digits.isEmpty() -> Hint("ਸੰਪਰਕ ਲੱਭਣ ਲਈ ਟਾਈਪ ਕਰੋ", muted)
                vm.results.isEmpty() -> Hint("ਕੋਈ ਨਤੀਜਾ ਨਹੀਂ ਮਿਲਿਆ", muted)
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.results, key = { it.contact.id to it.contact.number }) { m ->
                        ResultRow(m) { onCall(m.contact.number) }
                    }
                }
            }
        }
        Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
        CallRow(
            hasDigits = vm.digits.isNotEmpty(),
            onCall = { if (vm.digits.isNotEmpty()) onCall(vm.digits) },
            onBackspace = vm::backspace,
            onClear = vm::clear,
        )
    }
}

@Composable
private fun BoxScope.Hint(text: String, color: Color) {
    Text(
        text,
        fontSize = 14.sp,
        color = color,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
    )
}

@Composable
private fun ResultRow(m: Match, onClick: () -> Unit) {
    val name = m.contact.name
    val accent = MaterialTheme.colorScheme.primary
    val text = buildAnnotatedString {
        val h = m.highlight
        if (h == null) {
            append(name)
        } else {
            val s = h.first.coerceIn(0, name.length)
            val e = (h.last + 1).coerceIn(s, name.length)
            append(name.substring(0, s))
            withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Medium)) {
                append(name.substring(s, e))
            }
            append(name.substring(e))
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.take(1), color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.padding(start = 16.dp)) {
            Text(text, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
            Text(m.contact.number, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Keypad(onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { KeyButton(it, onKey, onLongKey) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeyButton(digit: Char, onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val sub = if (digit == '0') "+" else GurmukhiKeys.label(digit).replace(" ", "")
    Box(
        Modifier
            .size(74.dp)
            .clip(CircleShape)
            .background(scheme.surfaceVariant)
            .combinedClickable(onClick = { onKey(digit) }, onLongClick = { onLongKey(digit) }),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(digit.toString(), fontSize = 24.sp, color = scheme.onBackground)
                if (digit.isDigit()) {
                    Spacer(Modifier.width(4.dp))
                    Text(
                        GURMUKHI_DIGITS[digit - '0'].toString(),
                        fontSize = 15.sp,
                        color = scheme.primary,
                        modifier = Modifier.padding(bottom = 2.dp),
                    )
                }
            }
            if (sub.isNotEmpty()) {
                Text(sub, fontSize = 11.sp, color = scheme.onSurfaceVariant, maxLines = 1, softWrap = false)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CallRow(hasDigits: Boolean, onCall: () -> Unit, onBackspace: () -> Unit, onClear: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(60.dp).clip(CircleShape).background(CallGreen).clickable(onClick = onCall),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Call, contentDescription = "ਕਾਲ", tint = Color.White)
            }
        }
        Box(
            Modifier.weight(1f).height(60.dp).combinedClickable(onClick = onBackspace, onLongClick = onClear),
            contentAlignment = Alignment.Center,
        ) {
            if (hasDigits) {
                Text("⌫", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    NavigationBar(containerColor = scheme.background) {
        TABS.forEachIndexed { i, label ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = {
                    when (i) {
                        0 -> Icon(Icons.Filled.Star, contentDescription = null, tint = FavoriteOrange)
                        1 -> ClockIcon()
                        2 -> DialpadIcon()
                        else -> Icon(Icons.Filled.Person, contentDescription = null)
                    }
                },
                label = { Text(label, fontSize = 12.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = scheme.primary,
                    selectedTextColor = scheme.primary,
                    indicatorColor = scheme.secondaryContainer,
                    unselectedIconColor = scheme.onSurfaceVariant,
                    unselectedTextColor = scheme.onSurfaceVariant,
                ),
            )
        }
    }
}

@Composable
private fun ClockIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(24.dp)) {
        val stroke = 2.dp.toPx()
        val r = size.minDimension / 2 - stroke
        drawCircle(color, radius = r, style = Stroke(stroke))
        drawLine(color, center, Offset(center.x, center.y - r * 0.55f), stroke, StrokeCap.Round)
        drawLine(color, center, Offset(center.x + r * 0.4f, center.y + r * 0.15f), stroke, StrokeCap.Round)
    }
}

@Composable
private fun DialpadIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(24.dp)) {
        val gap = size.width / 4
        for (row in 1..3) for (col in 1..3) {
            drawCircle(color, radius = 2.dp.toPx(), center = Offset(col * gap, row * gap))
        }
    }
}
