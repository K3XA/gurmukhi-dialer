package com.example.gurmukhidialer.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gurmukhidialer.smartdial.GurmukhiKeys
import com.example.gurmukhidialer.smartdial.LatinT9
import com.example.gurmukhidialer.smartdial.Match

private val KEYS = "123456789*0#".toList()

@Composable
fun DialerScreen(vm: DialerViewModel, onCall: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
    ) {
        Text(
            text = vm.digits.ifEmpty { "Enter a number or name" },
            fontSize = if (vm.digits.isEmpty()) 16.sp else 32.sp,
            color = if (vm.digits.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
        )
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(vm.results, key = { it.contact.id to it.contact.number }) { m ->
                ResultRow(m) { onCall(m.contact.number) }
            }
        }
        Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
        BottomRow(
            onCall = { if (vm.digits.isNotEmpty()) onCall(vm.digits) },
            onBackspace = vm::backspace,
            onClear = vm::clear,
        )
    }
}

@Composable
private fun ResultRow(m: Match, onClick: () -> Unit) {
    val name = m.contact.name
    val accent = MaterialTheme.colorScheme.primary
    val text = buildAnnotatedString {
        val h = m.highlight
        if (h == null) {
            append(name)
        } else {
            val s = h.first.coerceIn(0, name.length)
            val e = (h.last + 1).coerceIn(s, name.length)
            append(name.substring(0, s))
            withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Medium)) {
                append(name.substring(s, e))
            }
            append(name.substring(e))
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.take(1), color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.padding(start = 16.dp)) {
            Text(text, fontSize = 16.sp)
            Text(m.contact.number, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Keypad(onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { KeyButton(it, Modifier.weight(1f), onKey, onLongKey) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeyButton(digit: Char, modifier: Modifier, onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier
            .height(68.dp)
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(onClick = { onKey(digit) }, onLongClick = { onLongKey(digit) }),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(digit.toString(), fontSize = 24.sp)
        val gurmukhi = GurmukhiKeys.label(digit)
        if (gurmukhi.isNotEmpty()) Text(gurmukhi, fontSize = 12.sp, color = muted)
        val latin = if (digit == '0') "+" else LatinT9.label(digit)
        if (latin.isNotEmpty()) Text(latin, fontSize = 10.sp, color = muted)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BottomRow(onCall: () -> Unit, onBackspace: () -> Unit, onClear: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF2E7D32)).clickable(onClick = onCall),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Call, contentDescription = "Call", tint = Color.White)
            }
        }
        Box(
            Modifier.weight(1f).height(64.dp).combinedClickable(onClick = onBackspace, onLongClick = onClear),
            contentAlignment = Alignment.Center,
        ) {
            Text("⌫", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
