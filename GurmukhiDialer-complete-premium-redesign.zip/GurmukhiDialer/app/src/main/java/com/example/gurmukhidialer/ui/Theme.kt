package com.example.gurmukhidialer.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary=Color(0xFF087A59), onPrimary=Color.White,
    primaryContainer=Color(0xFFD2F2E5), onPrimaryContainer=Color(0xFF053A2A),
    secondary=Color(0xFF516960), secondaryContainer=Color(0xFFE1ECE7), onSecondaryContainer=Color(0xFF12201B),
    background=Color(0xFFF5F7F6), onBackground=Color(0xFF151A18),
    surface=Color(0xFFFFFFFF), onSurface=Color(0xFF151A18),
    surfaceVariant=Color(0xFFEDF2EF), onSurfaceVariant=Color(0xFF69756F),
    outlineVariant=Color(0xFFDCE5E0)
)
private val DarkColors = darkColorScheme(
    primary=Color(0xFF4ED8A7), onPrimary=Color(0xFF003727),
    primaryContainer=Color(0xFF07563F), onPrimaryContainer=Color(0xFFB7F2D9),
    secondary=Color(0xFFB6CBC2), secondaryContainer=Color(0xFF24352E), onSecondaryContainer=Color(0xFFD8E8E2),
    background=Color(0xFF090D0B), onBackground=Color(0xFFE9F0EC),
    surface=Color(0xFF111714), onSurface=Color(0xFFE9F0EC),
    surfaceVariant=Color(0xFF1B2420), onSurfaceVariant=Color(0xFFA2B0A9),
    outlineVariant=Color(0xFF29332F)
)

private const val PREFS="gurmukhi_dialer_prefs"
private const val KEY="dark_override"

object ThemeController {
    var darkOverride by mutableStateOf<Boolean?>(null); private set
    private var loaded=false
    fun loadIfNeeded(c:Context){if(!loaded){loaded=true;val p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);darkOverride=if(p.contains(KEY))p.getBoolean(KEY,false)else null}}
    fun setDarkOverride(c:Context,v:Boolean){darkOverride=v;c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putBoolean(KEY,v).apply()}
}
@Composable fun isAppInDarkTheme():Boolean=ThemeController.darkOverride ?: isSystemInDarkTheme()
@Composable fun GurmukhiDialerTheme(content:@Composable()->Unit){
    val c=LocalContext.current
    LaunchedEffect(Unit){ThemeController.loadIfNeeded(c)}
    MaterialTheme(colorScheme=if(isAppInDarkTheme())DarkColors else LightColors){
        Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background,content=content)
    }
}
