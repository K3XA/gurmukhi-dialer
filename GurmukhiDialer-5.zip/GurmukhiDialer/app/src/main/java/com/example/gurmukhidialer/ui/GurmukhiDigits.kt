package com.example.gurmukhidialer.ui

private const val GURMUKHI_DIGITS = "੦੧੨੩੪੫੬੭੮੯"

/** Shows 0-9 as Gurmukhi numerals. Display only; dialing still uses plain digits. */
fun String.toGurmukhiDigits(): String = buildString {
    for (c in this@toGurmukhiDigits) append(if (c in '0'..'9') GURMUKHI_DIGITS[c - '0'] else c)
}
