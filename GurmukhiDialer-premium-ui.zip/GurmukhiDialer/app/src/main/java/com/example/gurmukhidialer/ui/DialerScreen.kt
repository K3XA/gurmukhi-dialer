package com.example.gurmukhidialer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gurmukhidialer.data.RecentCall
import com.example.gurmukhidialer.smartdial.GurmukhiKeys
import com.example.gurmukhidialer.smartdial.Match

private val KEYS = "123456789*0#".toList()
private val TABS = listOf("ਮਨਪਸੰਦ", "ਹਾਲੀਆ", "ਕੀਪੈਡ", "ਸੰਪਰਕ")
private const val KEYPAD_TAB = 2
private val FavoriteGold = Color(0xFFE7A93B)
private val PremiumGreen = Color(0xFF19A974)
private val PremiumGreenDark = Color(0xFF0E8F60)
private val KeyShape = RoundedCornerShape(24.dp)

@Composable
fun DialerScreen(vm: DialerViewModel, onCall: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(KEYPAD_TAB) }

    Column(
        Modifier
            .fillMaxSize()
            .background(screenBrush())
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        PremiumTopBar()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                KEYPAD_TAB -> KeypadTab(vm, onCall, onSeeAllRecents = { tab = 1 })
                else -> PolishedEmptyTab(tab)
            }
        }
        BottomNav(tab) { tab = it }
    }
}

@Composable
private fun screenBrush(): Brush {
    val dark = isAppInDarkTheme()
    return if (dark) {
        Brush.verticalGradient(
            listOf(Color(0xFF090B0E), Color(0xFF10151A), Color(0xFF0B0D10))
        )
    } else {
        Brush.verticalGradient(
            listOf(Color(0xFFF7F9F8), Color(0xFFFFFFFF), Color(0xFFF4F7F6))
        )
    }
}

@Composable
private fun PremiumTopBar() {
    val scheme = MaterialTheme.colorScheme
    val dark = isAppInDarkTheme()
    val context = LocalContext.current

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "ਫ਼ੋਨ",
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                color = scheme.onBackground,
                letterSpacing = (-0.4).sp
            )
            Text(
                "ਸੰਪਰਕ ਅਤੇ ਕਾਲਾਂ",
                fontSize = 12.sp,
                color = scheme.onSurfaceVariant
            )
        }

        TopIconButton(
            icon = if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
            description = "ਥੀਮ ਬਦਲੋ",
            onClick = { ThemeController.setDarkOverride(context, !dark) }
        )
        Spacer(Modifier.size(8.dp))
        TopIconButton(
            icon = Icons.Filled.Settings,
            description = "ਸੈਟਿੰਗਾਂ",
            onClick = {}
        )
    }
}

@Composable
private fun TopIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(19.dp)
        )
    }
}

@Composable
private fun KeypadTab(
    vm: DialerViewModel,
    onCall: (String) -> Unit,
    onSeeAllRecents: () -> Unit
) {
    if (vm.digits.isEmpty()) {
        Column(Modifier.fillMaxSize()) {
            SearchBar()

            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 12.dp)
                ) {
                    item {
                        SectionHeader("ਤਾਜ਼ਾ ਕਾਲਾਂ", "ਸਾਰੇ ਦੇਖੋ", onSeeAllRecents)
                    }
                    if (vm.recents.isEmpty()) {
                        item { EmptyRecents() }
                    } else {
                        items(vm.recents.take(4), key = { it.number + it.timeMillis }) { recent ->
                            RecentRow(recent) { onCall(recent.number) }
                        }
                    }
                }
            }

            Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
            CallRow(
                hasDigits = false,
                onCall = {},
                onBackspace = vm::backspace,
                onClear = vm::clear
            )
        }
        return
    }

    val listState = rememberLazyListState()
    LaunchedEffect(vm.results) { listState.scrollToItem(0) }

    Column(Modifier.fillMaxSize()) {
        NumberDisplay(vm.digits, onClear = vm::clear)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.results.isEmpty()) {
                Hint("ਕੋਈ ਸੰਪਰਕ ਨਹੀਂ ਮਿਲਿਆ", MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    state = listState,
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    items(vm.results, key = { it.contact.id to it.contact.number }) { match ->
                        ResultRow(match) { onCall(match.contact.number) }
                    }
                }
            }
        }

        Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
        CallRow(
            hasDigits = true,
            onCall = { onCall(vm.digits) },
            onBackspace = vm::backspace,
            onClear = vm::clear
        )
    }
}

@Composable
private fun SearchBar() {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .shadow(8.dp, RoundedCornerShape(18.dp), clip = false)
            .clip(RoundedCornerShape(18.dp))
            .background(scheme.surface)
            .padding(horizontal = 15.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Search,
            contentDescription = null,
            tint = scheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Text(
            "ਸੰਪਰਕ ਲੱਭੋ ਜਾਂ ਨੰਬਰ ਦਰਜ ਕਰੋ",
            fontSize = 14.sp,
            color = scheme.onSurfaceVariant,
            modifier = Modifier.weight(1f).padding(start = 10.dp)
        )
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(scheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Add,
                contentDescription = "ਨਵਾਂ ਸੰਪਰਕ",
                tint = scheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun NumberDisplay(number: String, onClear: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(scheme.surface.copy(alpha = 0.9f))
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            number.toGurmukhiDigits(),
            fontSize = 34.sp,
            fontWeight = FontWeight.Medium,
            color = scheme.onSurface,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp)
        )
        if (number.isNotEmpty()) {
            Text(
                "×",
                fontSize = 24.sp,
                color = scheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .clip(CircleShape)
                    .clickable(onClick = onClear)
                    .padding(4.dp)
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            action,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable(onClick = onClick)
        )
    }
}

@Composable
private fun EmptyRecents() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 24.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
            .padding(vertical = 26.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Call, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text("ਹਾਲੇ ਕੋਈ ਹਾਲੀਆ ਕਾਲ ਨਹੀਂ", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text("ਤੁਹਾਡੀਆਂ ਹਾਲੀਆ ਕਾਲਾਂ ਇੱਥੇ ਦਿਖਣਗੀਆਂ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RecentRow(r: RecentCall, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val label = r.name?.takeIf { it.isNotBlank() } ?: r.number
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(scheme.surface.copy(alpha = 0.78f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(label)
        Column(Modifier.weight(1f).padding(start = 13.dp)) {
            Text(
                if (label == r.number) label.toGurmukhiDigits() else label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = scheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                timeAgoGurmukhi(r.timeMillis),
                fontSize = 11.sp,
                color = scheme.onSurfaceVariant
            )
        }
        Box(
            Modifier.size(36.dp).clip(CircleShape)
                .background(PremiumGreen.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Call, "ਕਾਲ", tint = PremiumGreen, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.size(7.dp))
        Icon(Icons.Filled.ChevronRight, null, tint = scheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun Avatar(label: String) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(scheme.primary.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label.take(1),
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = scheme.primary
        )
    }
}

@Composable
private fun BoxScope.Hint(text: String, color: Color) {
    Text(text, fontSize = 14.sp, color = color, modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp))
}

@Composable
private fun ResultRow(m: Match, onClick: () -> Unit) {
    val name = m.contact.name
    val accent = MaterialTheme.colorScheme.primary
    val text = buildAnnotatedString {
        val h = m.highlight
        if (h == null) append(name) else {
            val s = h.first.coerceIn(0, name.length)
            val e = (h.last + 1).coerceIn(s, name.length)
            append(name.substring(0, s))
            withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Bold)) { append(name.substring(s, e)) }
            append(name.substring(e))
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.75f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(name)
        Column(Modifier.padding(start = 13.dp)) {
            Text(text, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(m.contact.number.toGurmukhiDigits(), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Keypad(onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 26.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        KEYS.chunked(3).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                row.forEach { key -> KeyButton(key, onKey, onLongKey) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeyButton(digit: Char, onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val sub = if (digit == '0') "+" else GurmukhiKeys.label(digit).replace(" ", "")
    Box(
        Modifier
            .size(68.dp)
            .shadow(4.dp, KeyShape, clip = false)
            .clip(KeyShape)
            .background(scheme.surface)
            .combinedClickable(
                onClick = { onKey(digit) },
                onLongClick = { onLongKey(digit) }
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                digit.toString().toGurmukhiDigits(),
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                color = scheme.onSurface
            )
            if (sub.isNotEmpty()) {
                Text(sub, fontSize = 9.sp, fontWeight = FontWeight.Medium, color = scheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CallRow(
    hasDigits: Boolean,
    onCall: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(66.dp)
                    .shadow(12.dp, CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(PremiumGreen, PremiumGreenDark)))
                    .clickable(enabled = hasDigits, onClick = onCall),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Call, "ਕਾਲ", tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(
                            alpha = if (hasDigits) 1f else 0.42f
                        )
                    )
                    .combinedClickable(onClick = onBackspace, onLongClick = onClear),
                contentAlignment = Alignment.Center
            ) {
                Text("⌫", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    HorizontalDivider(color = scheme.outlineVariant.copy(alpha = 0.6f))
    NavigationBar(
        containerColor = scheme.surface.copy(alpha = 0.96f),
        tonalElevation = 0.dp,
        modifier = Modifier.height(76.dp)
    ) {
        TABS.forEachIndexed { i, label ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = {
                    when (i) {
                        0 -> Icon(Icons.Filled.Star, null, tint = FavoriteGold, modifier = Modifier.size(19.dp))
                        1 -> ClockIcon()
                        2 -> DialpadIcon()
                        else -> Icon(Icons.Filled.Person, null, modifier = Modifier.size(19.dp))
                    }
                },
                label = { Text(label, fontSize = 10.sp, fontWeight = if (selected == i) FontWeight.SemiBold else FontWeight.Normal) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = scheme.primary,
                    selectedTextColor = scheme.primary,
                    indicatorColor = scheme.primary.copy(alpha = 0.11f),
                    unselectedIconColor = scheme.onSurfaceVariant,
                    unselectedTextColor = scheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
private fun PolishedEmptyTab(tab: Int) {
    val title = TABS[tab]
    val icon = when (tab) {
        0 -> Icons.Filled.Star
        1 -> Icons.Filled.Call
        else -> Icons.Filled.Person
    }
    Box(
        Modifier.fillMaxSize().padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.82f))
                .padding(vertical = 38.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(62.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.11f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Text(
                "ਇਹ ਭਾਗ ਤੁਹਾਡੇ ਡਾਟਾ ਨਾਲ ਆਪਣੇ ਆਪ ਭਰ ਜਾਵੇਗਾ।",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
    }
}

@Composable
private fun ClockIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(21.dp)) {
        val stroke = 2.dp.toPx()
        val r = size.minDimension / 2 - stroke
        drawCircle(color, radius = r, style = Stroke(stroke))
        drawLine(color, center, Offset(center.x, center.y - r * 0.55f), stroke, StrokeCap.Round)
        drawLine(color, center, Offset(center.x + r * 0.4f, center.y + r * 0.15f), stroke, StrokeCap.Round)
    }
}

@Composable
private fun DialpadIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(21.dp)) {
        val gap = size.width / 4
        for (row in 1..3) for (col in 1..3) {
            drawCircle(color, radius = 1.9.dp.toPx(), center = Offset(col * gap, row * gap))
        }
    }
}
