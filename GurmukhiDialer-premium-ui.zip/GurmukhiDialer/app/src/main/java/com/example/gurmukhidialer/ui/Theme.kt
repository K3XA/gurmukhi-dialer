package com.example.gurmukhidialer.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme

private val LightColors = lightColorScheme(
    primary = Color(0xFF087F5B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5F5E9),
    onPrimaryContainer = Color(0xFF063B2B),
    secondary = Color(0xFF526A61),
    secondaryContainer = Color(0xFFE0ECE7),
    onSecondaryContainer = Color(0xFF10201A),
    background = Color(0xFFF6F8F7),
    onBackground = Color(0xFF161B19),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF161B19),
    surfaceVariant = Color(0xFFEEF2F0),
    onSurfaceVariant = Color(0xFF66716C),
    outlineVariant = Color(0xFFDDE5E1)
)

val GradientStart = Color(0xFF19A974)
val GradientEnd = Color(0xFF087F5B)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF48D6A2),
    onPrimary = Color(0xFF003827),
    primaryContainer = Color(0xFF07553D),
    onPrimaryContainer = Color(0xFFB9F2D9),
    secondary = Color(0xFFB5CBC2),
    secondaryContainer = Color(0xFF24342E),
    onSecondaryContainer = Color(0xFFD8E9E3),
    background = Color(0xFF090C0B),
    onBackground = Color(0xFFE8EFEC),
    surface = Color(0xFF121715),
    onSurface = Color(0xFFE8EFEC),
    surfaceVariant = Color(0xFF1A211E),
    onSurfaceVariant = Color(0xFFA2B0AA),
    outlineVariant = Color(0xFF2A3530)
)

private const val PREFS_NAME = "gurmukhi_dialer_prefs"
private const val KEY_DARK_OVERRIDE = "dark_override"

object ThemeController {
    var darkOverride by mutableStateOf<Boolean?>(null)
        private set
    private var loaded = false

    fun loadIfNeeded(context: Context) {
        if (loaded) return
        loaded = true
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        darkOverride = if (prefs.contains(KEY_DARK_OVERRIDE)) {
            prefs.getBoolean(KEY_DARK_OVERRIDE, false)
        } else {
            null
        }
    }

    fun setDarkOverride(context: Context, value: Boolean) {
        darkOverride = value
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_DARK_OVERRIDE, value)
            .apply()
    }
}

@Composable
fun isAppInDarkTheme(): Boolean =
    ThemeController.darkOverride ?: isSystemInDarkTheme()

@Composable
fun GurmukhiDialerTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { ThemeController.loadIfNeeded(context) }
    val scheme = if (isAppInDarkTheme()) DarkColors else LightColors

    MaterialTheme(colorScheme = scheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
            content = content
        )
    }
}
