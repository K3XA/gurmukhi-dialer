package com.example.gurmukhidialer.data

import android.content.Context
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.PhoneLookup
import com.example.gurmukhidialer.smartdial.PhoneKey

data class RecentCall(val number: String, val name: String?, val timeMillis: Long)

data class CallHistoryEntry(
    val number: String,
    val name: String?,
    val timeMillis: Long,
    val durationSeconds: Long,
    val type: Int,
)

class ContactsRepository(private val context: Context) {

    fun loadContacts(): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            context.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, "${Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val number = c.getString(2) ?: continue
                    out += Contact(c.getLong(0), name, number)
                }
            }
        } catch (_: SecurityException) {
        }
        return out.distinctBy { it.id to PhoneKey.of(it.number) }
    }

    /** Calls per number over the last 90 days, keyed by [PhoneKey.of]. */
    fun recentCallCounts(): Map<String, Int> {
        val counts = HashMap<String, Int>()
        val since = System.currentTimeMillis() - 90L * 24 * 60 * 60 * 1000
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER),
                "${CallLog.Calls.DATE} > ?", arrayOf(since.toString()), null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val key = PhoneKey.of(c.getString(0) ?: continue)
                    if (key.isNotEmpty()) counts[key] = (counts[key] ?: 0) + 1
                }
            }
        } catch (_: SecurityException) {
        }
        return counts
    }

    /** Most recent calls, one per distinct number, newest first. */
    fun recentCalls(limit: Int = 3): List<RecentCall> {
        val out = ArrayList<RecentCall>()
        val seen = HashSet<String>()
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE),
                null, null, "${CallLog.Calls.DATE} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val number = c.getString(0) ?: continue
                    val key = PhoneKey.of(number)
                    if (key.isEmpty() || !seen.add(key)) continue
                    out += RecentCall(number, c.getString(1), c.getLong(2))
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    /** Full recent call log, newest first. */
    fun allCallHistory(limit: Int = 150): List<CallHistoryEntry> {
        val out = ArrayList<CallHistoryEntry>()
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.DATE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.TYPE,
                ),
                null, null, "${CallLog.Calls.DATE} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val number = c.getString(0) ?: continue
                    if (number.isBlank()) continue
                    out += CallHistoryEntry(
                        number = number,
                        name = c.getString(1),
                        timeMillis = c.getLong(2),
                        durationSeconds = c.getLong(3),
                        type = c.getInt(4),
                    )
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    /** Full call history for one phone number, newest first. */
    fun callHistory(number: String, limit: Int = 100): List<CallHistoryEntry> {
        val out = ArrayList<CallHistoryEntry>()
        if (number.isBlank()) return out
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.DATE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.TYPE,
                ),
                null,
                null,
                "${CallLog.Calls.DATE} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val entryNumber = c.getString(0) ?: continue
                    if (PhoneKey.of(entryNumber) != PhoneKey.of(number)) continue
                    out += CallHistoryEntry(
                        number = entryNumber,
                        name = c.getString(1),
                        timeMillis = c.getLong(2),
                        durationSeconds = c.getLong(3),
                        type = c.getInt(4),
                    )
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    fun lookupName(number: String): String? {
        if (number.isBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            context.contentResolver.query(uri, arrayOf(PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: SecurityException) {
            null
        }
    }
}
