package com.example.gurmukhidialer.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.gurmukhidialer.data.ContactsRepository
import com.example.gurmukhidialer.data.RecentCall
import com.example.gurmukhidialer.data.CallHistoryEntry
import com.example.gurmukhidialer.smartdial.IndexedContact
import com.example.gurmukhidialer.smartdial.Match
import com.example.gurmukhidialer.smartdial.SmartDialMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DialerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContactsRepository(app)
    private var index: List<IndexedContact> = emptyList()
    private var recency: Map<String, Int> = emptyMap()

    var digits by mutableStateOf("")
        private set
    var results by mutableStateOf<List<Match>>(emptyList())
        private set
    var recents by mutableStateOf<List<RecentCall>>(emptyList())
        private set

    var contacts by mutableStateOf<List<com.example.gurmukhidialer.data.Contact>>(emptyList())
        private set

    var recentHistory by mutableStateOf<List<CallHistoryEntry>>(emptyList())
        private set

    var selectedHistory by mutableStateOf<RecentCall?>(null)
        private set

    var history by mutableStateOf<List<CallHistoryEntry>>(emptyList())
        private set

    /** Call after contacts and call-log permissions are granted. */
    fun reload() {
        viewModelScope.launch {
            val (idx, calls) = withContext(Dispatchers.IO) {
                repo.loadContacts().map(SmartDialMatcher::index) to repo.recentCallCounts()
            }
            index = idx
            contacts = idx.map { it.contact }.distinctBy { it.id to it.number }
            recency = calls
            recents = withContext(Dispatchers.IO) { repo.recentCalls(limit = 20) }
            recentHistory = withContext(Dispatchers.IO) { repo.allCallHistory(limit = 150) }
            refresh()
        }
    }

    fun press(d: Char) { digits += d; refresh() }
    fun backspace() { digits = digits.dropLast(1); refresh() }
    fun clear() { digits = ""; refresh() }
    fun setNumber(number: String) { digits = number; refresh() }

    fun openHistory(call: RecentCall) {
        selectedHistory = call
        history = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            val loaded = repo.callHistory(call.number)
            withContext(Dispatchers.Main) { history = loaded }
        }
    }

    fun closeHistory() {
        selectedHistory = null
        history = emptyList()
    }

    private fun refresh() {
        results = SmartDialMatcher.search(digits, index, recency).take(30)
    }
}
