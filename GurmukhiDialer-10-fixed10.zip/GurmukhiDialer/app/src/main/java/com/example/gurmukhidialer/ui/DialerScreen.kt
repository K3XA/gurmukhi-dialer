package com.example.gurmukhidialer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import com.example.gurmukhidialer.data.RecentCall
import com.example.gurmukhidialer.smartdial.PhoneKey
import com.example.gurmukhidialer.data.CallHistoryEntry
import android.provider.CallLog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.example.gurmukhidialer.smartdial.GurmukhiKeys
import com.example.gurmukhidialer.smartdial.Match

private val KEYS = "123456789*0#".toList()
private val TABS = listOf("ਮਨਪਸੰਦ", "ਹਾਲੀਆ", "ਕੀਪੈਡ", "ਸੰਪਰਕ")
private const val KEYPAD_TAB = 2
private val CallRed = Color(0xFFE8494F)
private val KeyShape = RoundedCornerShape(22.dp)
private val FavoriteOrange = Color(0xFFF2A03D)

@Composable
fun DialerScreen(vm: DialerViewModel, onCall: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(KEYPAD_TAB) }

    if (vm.selectedHistory != null) {
        HistoryScreen(
            call = vm.selectedHistory!!,
            history = vm.history,
            onBack = vm::closeHistory,
            onCall = onCall,
        )
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(screenBrush())
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        if (!(tab == KEYPAD_TAB && vm.digits.isEmpty())) Header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == KEYPAD_TAB) {
                KeypadTab(vm, onCall, onSeeAllRecents = { tab = 1 }, onOpenHistory = vm::openHistory)
            } else if (tab == 1) {
                RecentCallsTab(
                    calls = vm.recentHistory,
                    onCall = onCall,
                    onOpenHistory = vm::openHistory,
                )
            } else if (tab == 3) {
                ContactsTab(
                    contacts = vm.contacts,
                    onCall = onCall,
                    onOpenHistory = { contact ->
                        vm.openHistory(RecentCall(contact.number, contact.name, System.currentTimeMillis()))
                    },
                )
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "${TABS[tab]} – ਜਲਦੀ ਆ ਰਿਹਾ ਹੈ",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        BottomNav(tab) {
            tab = it
            if (it == 1 || it == 3) vm.reload()
        }
    }
}

@Composable
private fun screenBrush(): Brush =
    if (isAppInDarkTheme()) Brush.verticalGradient(listOf(Color(0xFF07090D), Color(0xFF262C39)))
    else SolidColor(MaterialTheme.colorScheme.background)

@Composable
private fun Header() {
    val scheme = MaterialTheme.colorScheme
    val dark = isAppInDarkTheme()
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (dark) Icons.Filled.DarkMode else Icons.Filled.LightMode,
            contentDescription = "ਥੀਮ ਬਦਲੋ",
            tint = scheme.primary,
            modifier = Modifier
                .size(22.dp)
                .clickable { ThemeController.setDarkOverride(context, !dark) },
        )
        Icon(Icons.Filled.Settings, contentDescription = null, tint = scheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun RecentCallsTab(
    calls: List<CallHistoryEntry>,
    onCall: (String) -> Unit,
    onOpenHistory: (RecentCall) -> Unit,
) {
    var filter by remember { mutableIntStateOf(0) }
    val scheme = MaterialTheme.colorScheme
    val filtered = when (filter) {
        1 -> calls.filter { it.type == CallLog.Calls.MISSED_TYPE }
        2 -> calls.filter { it.type == CallLog.Calls.INCOMING_TYPE }
        3 -> calls.filter { it.type == CallLog.Calls.OUTGOING_TYPE }
        else -> calls
    }

    // The call log can contain many records for the same number. On the
    // recent-calls page we show one clean card per number instead of making
    // the same contact appear repeatedly. The full history remains available
    // after opening the card.
    val grouped = filtered
        .groupBy { PhoneKey.of(it.number) }
        .values
        .map { entries -> entries.sortedByDescending { it.timeMillis } }
        .sortedByDescending { it.first().timeMillis }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "ਹਾਲੀਆ ਕਾਲਾਂ",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                color = scheme.onBackground,
            )
            Text(
                "${grouped.size.toString().toGurmukhiDigits()} ਸੰਪਰਕ",
                fontSize = 13.sp,
                color = scheme.onSurfaceVariant,
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                RecentFilterRow(selected = filter, onSelected = { filter = it })
            }
            if (grouped.isEmpty()) {
                item {
                    Box(
                        Modifier.fillMaxWidth().height(360.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("ਹਾਲੇ ਕੋਈ ਕਾਲ ਨਹੀਂ", color = scheme.onSurfaceVariant, fontSize = 16.sp)
                    }
                }
            } else {
                // Do not use call-log fields as the LazyColumn key: two call-log
                // records can legitimately have the same timestamp/number/type.
                // Duplicate keys can crash Compose while scrolling or changing filters.
                items(grouped.size, key = { index -> PhoneKey.of(grouped[index].first().number) }) { index ->
                    val entries = grouped[index]
                    val entry = entries.first()
                    RecentCallCard(
                        entry = entry,
                        callCount = entries.size,
                        onOpenHistory = {
                            onOpenHistory(
                                RecentCall(entry.number, entry.name, entry.timeMillis)
                            )
                        },
                        onCall = { onCall(entry.number) },
                    )
                }
            }
        }
    }
}

@Composable
private fun RecentFilterRow(selected: Int, onSelected: (Int) -> Unit) {
    val labels = listOf("ਸਭ", "ਮਿਸਡ", "ਆਉਣ ਵਾਲੀਆਂ", "ਜਾਣ ਵਾਲੀਆਂ")
    Row(
        Modifier.fillMaxWidth().padding(bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val active = selected == index
            Box(
                Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (active) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)
                    .clickable { onSelected(index) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Text(
                    label,
                    fontSize = 12.sp,
                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun RecentCallCard(
    entry: CallHistoryEntry,
    callCount: Int,
    onOpenHistory: () -> Unit,
    onCall: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val (label, accent, arrow) = when (entry.type) {
        CallLog.Calls.MISSED_TYPE -> Triple("ਮਿਸਡ ਕਾਲ", CallRed, "×")
        CallLog.Calls.INCOMING_TYPE -> Triple("ਆਉਣ ਵਾਲੀ ਕਾਲ", Color(0xFF2097E8), "↙")
        CallLog.Calls.OUTGOING_TYPE -> Triple("ਕੀਤੀ ਗਈ ਕਾਲ", Color(0xFF20B95A), "↗")
        else -> Triple("ਕਾਲ", scheme.primary, "•")
    }
    val name = entry.name?.takeIf { it.isNotBlank() } ?: entry.number.toGurmukhiDigits()
    val avatar = entry.name?.firstOrNull()?.toString() ?: "+"

    Row(
        Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(22.dp), clip = false)
            .clip(RoundedCornerShape(22.dp))
            .background(scheme.surface)
            .clickable(onClick = onOpenHistory)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(accent),
            contentAlignment = Alignment.Center,
        ) {
            Text(avatar, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(arrow, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 23.dp, top = 20.dp))
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${label}  •  ${formatHistoryTime(entry.timeMillis)}",
                fontSize = 12.sp,
                color = scheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            if (callCount > 1) {
                Text(
                    "${callCount.toString().toGurmukhiDigits()} ਕਾਲਾਂ",
                    fontSize = 11.sp,
                    color = scheme.onSurfaceVariant,
                )
            } else if (entry.durationSeconds > 0) {
                Text(formatDuration(entry.durationSeconds), fontSize = 11.sp, color = scheme.onSurfaceVariant)
            } else {
                Text("—", fontSize = 12.sp, color = scheme.onSurfaceVariant)
            }
            Icon(
                Icons.Filled.Call,
                contentDescription = "ਕਾਲ ਕਰੋ",
                tint = scheme.primary,
                modifier = Modifier.size(38.dp).padding(9.dp).clickable(onClick = onCall),
            )
        }
    }
}

@Composable
private fun KeypadTab(
    vm: DialerViewModel,
    onCall: (String) -> Unit,
    onSeeAllRecents: () -> Unit,
    onOpenHistory: (RecentCall) -> Unit,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    if (vm.digits.isEmpty()) {
        // Keep the keypad and call controls pinned to the bottom of the keypad page.
        // Only the recent-calls area scrolls, so the keypad can never be pushed off-screen.
        Column(Modifier.fillMaxSize()) {
            Header()
            SearchBar()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 8.dp),
                ) {
                    if (vm.recents.isNotEmpty()) {
                        item {
                            RecentsSection(vm.recents, onSeeAll = onSeeAllRecents, onCall = onCall, onOpenHistory = onOpenHistory)
                        }
                    }
                }
            }
            Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
            CallRow(hasDigits = false, onCall = {}, onBackspace = vm::backspace, onClear = vm::clear)
        }
        return
    }
    val listState = rememberLazyListState()
    // Always show the best match first when the digits change.
    LaunchedEffect(vm.results) { listState.scrollToItem(0) }
    Column(Modifier.fillMaxSize()) {
        Text(
            text = vm.digits.toGurmukhiDigits(),
            fontSize = 34.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.results.isEmpty()) {
                Hint("ਕੋਈ ਨਤੀਜਾ ਨਹੀਂ ਮਿਲਿਆ", muted)
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    items(vm.results, key = { it.contact.id to it.contact.number }) { m ->
                        ResultRow(m, onOpenHistory = { onOpenHistory(RecentCall(m.contact.number, m.contact.name, System.currentTimeMillis())) }, onCall = { onCall(m.contact.number) })
                    }
                }
            }
        }
        Keypad(onKey = vm::press, onLongKey = { if (it == '0') vm.press('+') })
        CallRow(
            hasDigits = true,
            onCall = { onCall(vm.digits) },
            onBackspace = vm::backspace,
            onClear = vm::clear,
        )
    }
}

@Composable
private fun SearchBar() {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 3.dp)
            .shadow(3.dp, RoundedCornerShape(16.dp), clip = false)
            .clip(RoundedCornerShape(16.dp))
            .background(scheme.surface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = scheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Text(
            "ਸੰਪਰਕ ਲੱਭੋ...",
            fontSize = 15.sp,
            color = scheme.onSurfaceVariant,
            modifier = Modifier.weight(1f).padding(start = 10.dp),
        )
        Icon(Icons.Filled.Add, contentDescription = "ਨਵਾਂ ਸੰਪਰਕ", tint = scheme.primary, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun RecentsSection(
    recents: List<RecentCall>,
    onSeeAll: () -> Unit,
    onCall: (String) -> Unit,
    onOpenHistory: (RecentCall) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    if (recents.isEmpty()) return
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("ਤਾਜ਼ਾ ਸੰਪਰਕ", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = scheme.onSurfaceVariant)
            Text(
                "ਸਾਰੇ ਦੇਖੋ  ›",
                fontSize = 13.sp,
                color = scheme.primary,
                modifier = Modifier.clickable(onClick = onSeeAll),
            )
        }
        recents.forEach { r -> RecentRow(r, onOpenHistory = { onOpenHistory(r) }, onCall = { onCall(r.number) }) }
    }
}

private val AvatarPalette = listOf(
    Color(0xFF6C63FF), Color(0xFFE05B9A), Color(0xFF2FAE6B),
    Color(0xFFF2A03D), Color(0xFF3D9BE9), Color(0xFF9B5DE5),
)

@Composable
private fun RecentRow(r: RecentCall, onOpenHistory: () -> Unit, onCall: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val label = r.name?.takeIf { it.isNotBlank() } ?: r.number
    val avatarColor = AvatarPalette[(label.hashCode().let { if (it < 0) -it else it }) % AvatarPalette.size]
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 5.dp)
            .shadow(2.dp, RoundedCornerShape(14.dp), clip = false)
            .clip(RoundedCornerShape(14.dp))
            .background(scheme.surface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Contact/name area opens history. It never places a call.
        Row(
            Modifier.weight(1f).clickable(onClick = onOpenHistory),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(avatarColor),
                contentAlignment = Alignment.Center,
            ) {
                Text(label.take(1), color = Color.White, fontWeight = FontWeight.Medium)
            }
            Column(Modifier.padding(start = 14.dp)) {
                Text(label.let { if (it == r.number) it.toGurmukhiDigits() else it }, fontSize = 15.sp, color = scheme.onBackground)
                Text(timeAgoGurmukhi(r.timeMillis), fontSize = 12.sp, color = scheme.onSurfaceVariant)
            }
        }
        // Only this phone icon starts a call.
        Icon(
            Icons.Filled.Call,
            contentDescription = "ਕਾਲ",
            tint = scheme.primary,
            modifier = Modifier.size(36.dp).padding(9.dp).clickable(onClick = onCall),
        )
        Icon(
            Icons.Filled.ChevronRight,
            contentDescription = "ਇਤਿਹਾਸ",
            tint = scheme.onSurfaceVariant,
            modifier = Modifier.size(30.dp).clickable(onClick = onOpenHistory),
        )
    }
}


@Composable
private fun ContactsTab(
    contacts: List<com.example.gurmukhidialer.data.Contact>,
    onCall: (String) -> Unit,
    onOpenHistory: (com.example.gurmukhidialer.data.Contact) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val filtered = remember(contacts, query) {
        val q = query.trim()
        val result = if (q.isEmpty()) contacts else contacts.filter { contact ->
            contact.name.contains(q, ignoreCase = true) ||
                contact.number.contains(q) ||
                PhoneKey.of(contact.number).contains(PhoneKey.of(q))
        }
        result.distinctBy { it.id to PhoneKey.of(it.number) }
    }
    val gurmukhiContacts = filtered.filter { isGurmukhiName(it.name) }.sortedBy { it.name }
    val otherContacts = filtered.filterNot { isGurmukhiName(it.name) }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })

    Column(Modifier.fillMaxSize()) {
        Text(
            "ਸੰਪਰਕ",
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
            color = scheme.onBackground,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp)
                .shadow(3.dp, RoundedCornerShape(18.dp), clip = false)
                .clip(RoundedCornerShape(18.dp))
                .background(scheme.surface)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Search, contentDescription = "ਖੋਜ", tint = scheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
            androidx.compose.foundation.text.BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, color = scheme.onSurface),
                modifier = Modifier.weight(1f).padding(start = 10.dp),
                decorationBox = { inner ->
                    if (query.isEmpty()) {
                        Text("ਸੰਪਰਕ ਲੱਭੋ...", fontSize = 15.sp, color = scheme.onSurfaceVariant)
                    }
                    inner()
                },
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${filtered.size.toString().toGurmukhiDigits()} ਸੰਪਰਕ",
                fontSize = 13.sp,
                color = scheme.onSurfaceVariant,
            )
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(scheme.primaryContainer)
                    .clickable { addNewContact(context) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "ਨਵਾਂ ਸੰਪਰਕ", tint = scheme.primary)
            }
        }

        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (contacts.isEmpty()) "ਕੋਈ ਸੰਪਰਕ ਨਹੀਂ ਮਿਲਿਆ" else "ਕੋਈ ਮੇਲ ਨਹੀਂ ਮਿਲਿਆ",
                    color = scheme.onSurfaceVariant,
                    fontSize = 16.sp,
                )
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (gurmukhiContacts.isNotEmpty()) {
                    item(key = "gurmukhi_header") {
                        ContactSectionTitle("ਗੁਰਮੁਖੀ")
                    }
                    items(gurmukhiContacts, key = { "g_" + it.id.toString() + "_" + PhoneKey.of(it.number) }) { contact ->
                        ContactListCard(
                            contact = contact,
                            onOpenHistory = { onOpenHistory(contact) },
                            onCall = { onCall(contact.number) },
                            onEdit = { editContact(context, contact.id) },
                        )
                    }
                }
                if (otherContacts.isNotEmpty()) {
                    item(key = "english_header") {
                        ContactSectionTitle("ਅੰਗਰੇਜ਼ੀ")
                    }
                    items(otherContacts, key = { "e_" + it.id.toString() + "_" + PhoneKey.of(it.number) }) { contact ->
                        ContactListCard(
                            contact = contact,
                            onOpenHistory = { onOpenHistory(contact) },
                            onCall = { onCall(contact.number) },
                            onEdit = { editContact(context, contact.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactListCard(
    contact: com.example.gurmukhidialer.data.Contact,
    onOpenHistory: () -> Unit,
    onCall: () -> Unit,
    onEdit: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val label = contact.name.ifBlank { contact.number.toGurmukhiDigits() }
    val avatarColor = AvatarPalette[(label.hashCode().let { if (it == Int.MIN_VALUE) 0 else kotlin.math.abs(it) }) % AvatarPalette.size]
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(22.dp), clip = false)
            .clip(RoundedCornerShape(22.dp))
            .background(scheme.surface)
            .clickable(onClick = onOpenHistory)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(54.dp).clip(CircleShape).background(avatarColor),
            contentAlignment = Alignment.Center,
        ) {
            Text(label.take(1), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium)
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(contact.number.toGurmukhiDigits(), fontSize = 13.sp, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            Icons.Filled.Call,
            contentDescription = "ਕਾਲ ਕਰੋ",
            tint = scheme.primary,
            modifier = Modifier.size(44.dp).padding(9.dp).clickable(onClick = onCall),
        )
        Icon(
            Icons.Filled.Edit,
            contentDescription = "ਸੰਪਰਕ ਸੋਧੋ",
            tint = scheme.onSurfaceVariant,
            modifier = Modifier.size(36.dp).padding(8.dp).clickable(onClick = onEdit),
        )
        Icon(
            Icons.Filled.ChevronRight,
            contentDescription = "ਇਤਿਹਾਸ",
            tint = scheme.onSurfaceVariant,
            modifier = Modifier.size(30.dp),
        )
    }
}

@Composable
private fun ContactSectionTitle(title: String) {
    Text(
        title,
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
    )
}

private fun isGurmukhiName(name: String): Boolean {
    val first = name.firstOrNull { !it.isWhitespace() } ?: return false
    return first.code in 0x0A00..0x0A7F
}

private fun addNewContact(context: android.content.Context) {
    val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
        type = ContactsContract.RawContacts.CONTENT_TYPE
    }
    try { context.startActivity(intent) } catch (_: ActivityNotFoundException) { }
}

private fun editContact(context: android.content.Context, contactId: Long) {
    val intent = Intent(Intent.ACTION_EDIT).apply {
        data = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, contactId.toString())
        type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
    }
    try { context.startActivity(intent) } catch (_: ActivityNotFoundException) { }
}

@Composable
private fun HistoryScreen(
    call: RecentCall,
    history: List<CallHistoryEntry>,
    onBack: () -> Unit,
    onCall: (String) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val name = call.name?.takeIf { it.isNotBlank() } ?: call.number.toGurmukhiDigits()

    Column(
        Modifier
            .fillMaxSize()
            .background(screenBrush())
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "‹",
                fontSize = 34.sp,
                color = scheme.primary,
                modifier = Modifier.size(44.dp).clickable(onClick = onBack),
            )
            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                Text(name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = scheme.onBackground)
                if (call.name?.isNotBlank() == true) {
                    Text(call.number.toGurmukhiDigits(), fontSize = 13.sp, color = scheme.onSurfaceVariant)
                }
            }
            Icon(
                Icons.Filled.Call,
                contentDescription = "ਕਾਲ ਕਰੋ",
                tint = scheme.primary,
                modifier = Modifier.size(42.dp).padding(10.dp).clickable { onCall(call.number) },
            )
        }

        ContactActionCard(
            name = name,
            number = call.number,
            onWhatsApp = { openWhatsApp(context, call.number) },
            onCall = { onCall(call.number) },
            onMessage = { openMessages(context, call.number) },
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("ਕਾਲ ਇਤਿਹਾਸ", fontSize = 20.sp, fontWeight = FontWeight.Medium, color = scheme.onBackground)
            Box(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(scheme.surface)
                    .padding(horizontal = 18.dp, vertical = 8.dp),
            ) {
                Text("ਸਭ  ▾", fontSize = 14.sp, color = scheme.primary)
            }
        }

        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("ਕੋਈ ਕਾਲ ਇਤਿਹਾਸ ਨਹੀਂ", color = scheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxWidth().weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(history) { entry -> HistoryRow(entry) }
            }
        }
    }
}

@Composable
private fun ContactActionCard(
    name: String,
    number: String,
    onWhatsApp: () -> Unit,
    onCall: () -> Unit,
    onMessage: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .shadow(3.dp, RoundedCornerShape(24.dp), clip = false)
            .clip(RoundedCornerShape(24.dp))
            .background(scheme.surface)
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val initial = name.firstOrNull()?.toString() ?: "ਸ"
            Box(
                Modifier.size(58.dp).clip(CircleShape).background(scheme.primary),
                contentAlignment = Alignment.Center,
            ) { Text(initial, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium) }
            Column(Modifier.padding(start = 14.dp)) {
                Text(name, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface)
                Text(number.toGurmukhiDigits(), fontSize = 13.sp, color = scheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ActionItem(Icons.Filled.Chat, "ਵਟਸਐਪ", Color(0xFF20B95A), onWhatsApp)
            ActionItem(Icons.Filled.Call, "ਕਾਲ ਕਰੋ", scheme.primary, onCall)
            ActionItem(Icons.Filled.Chat, "ਸੰਦੇਸ਼", scheme.primary, onMessage)
        }
    }
}

@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
) {
    Column(
        Modifier.width(84.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 13.sp, color = tint, fontWeight = FontWeight.Medium)
    }
}

private fun openWhatsApp(context: android.content.Context, number: String) {
    val clean = number.filter(Char::isDigit)
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean")).apply {
        setPackage("com.whatsapp")
    }
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean")))
    }
}

private fun openMessages(context: android.content.Context, number: String) {
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
    try { context.startActivity(intent) } catch (_: ActivityNotFoundException) { }
}

@Composable
private fun HistoryRow(entry: CallHistoryEntry) {
    val scheme = MaterialTheme.colorScheme
    val (label, iconText, accent) = when (entry.type) {
        CallLog.Calls.MISSED_TYPE -> Triple("ਮਿਸਡ ਕਾਲ", "×", CallRed)
        CallLog.Calls.INCOMING_TYPE -> Triple("ਆਉਣ ਵਾਲੀ ਕਾਲ", "↙", Color(0xFF2097E8))
        CallLog.Calls.OUTGOING_TYPE -> Triple("ਕੀਤੀ ਗਈ ਕਾਲ", "↗", Color(0xFF20B95A))
        else -> Triple("ਕਾਲ", "•", scheme.primary)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(20.dp), clip = false)
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surface)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(25.dp))
            Text(iconText, fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(start = 23.dp, top = 19.dp))
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface)
            Text(
                formatHistoryTime(entry.timeMillis) + if (entry.durationSeconds > 0) "  •  ${formatDuration(entry.durationSeconds)}" else "",
                fontSize = 12.sp,
                color = scheme.onSurfaceVariant,
            )
        }
        Text("›", fontSize = 25.sp, color = scheme.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp))
    }
}

private fun formatDuration(seconds: Long): String {
    val min = seconds / 60
    val sec = seconds % 60
    return if (min > 0) "${min.toString().toGurmukhiDigits()} ਮਿੰਟ ${sec.toString().toGurmukhiDigits()} ਸਕਿੰਟ"
    else "${sec.toString().toGurmukhiDigits()} ਸਕਿੰਟ"
}

private fun formatHistoryTime(timeMillis: Long): String {
    val calendar = java.util.Calendar.getInstance().apply { timeInMillis = timeMillis }
    val months = listOf("ਜਨਵਰੀ", "ਫ਼ਰਵਰੀ", "ਮਾਰਚ", "ਅਪ੍ਰੈਲ", "ਮਈ", "ਜੂਨ", "ਜੁਲਾਈ", "ਅਗਸਤ", "ਸਤੰਬਰ", "ਅਕਤੂਬਰ", "ਨਵੰਬਰ", "ਦਸੰਬਰ")
    val day = calendar.get(java.util.Calendar.DAY_OF_MONTH).toString().toGurmukhiDigits()
    val month = months[calendar.get(java.util.Calendar.MONTH)]
    val hour24 = calendar.get(java.util.Calendar.HOUR_OF_DAY)
    val hour12 = (hour24 % 12).let { if (it == 0) 12 else it }.toString().toGurmukhiDigits()
    val minute = calendar.get(java.util.Calendar.MINUTE).toString().padStart(2, '0').toGurmukhiDigits()
    val period = when (hour24) {
        in 5..11 -> "ਸਵੇਰੇ"
        in 12..16 -> "ਦੁਪਹਿਰ"
        in 17..20 -> "ਸ਼ਾਮ"
        else -> "ਰਾਤ"
    }
    return "$day $month, $hour12:$minute $period"
}

@Composable
private fun BoxScope.Hint(text: String, color: Color) {
    Text(
        text,
        fontSize = 14.sp,
        color = color,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
    )
}

@Composable
private fun ResultRow(m: Match, onOpenHistory: () -> Unit, onCall: () -> Unit) {
    val name = m.contact.name
    val accent = MaterialTheme.colorScheme.primary
    val text = buildAnnotatedString {
        val h = m.highlight
        if (h == null) {
            append(name)
        } else {
            val s = h.first.coerceIn(0, name.length)
            val e = (h.last + 1).coerceIn(s, name.length)
            append(name.substring(0, s))
            withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Medium)) {
                append(name.substring(s, e))
            }
            append(name.substring(e))
        }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.take(1), color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.weight(1f).padding(start = 16.dp).clickable(onClick = onOpenHistory)) {
            Text(text, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
            Text(m.contact.number.toGurmukhiDigits(), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            Icons.Filled.Call,
            contentDescription = "ਕਾਲ",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(38.dp).padding(9.dp).clickable(onClick = onCall),
        )
    }
}

@Composable
private fun Keypad(onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    // Keep a deliberate visual gap above the keypad so it never appears
    // to grow directly out of / get cut off by the last recent-call card.
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 24.dp, end = 24.dp, top = 10.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { KeyButton(it, onKey, onLongKey) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeyButton(digit: Char, onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val dark = isAppInDarkTheme()
    // High-contrast keypad typography: dark in light mode and near-white in dark mode.
    val keyText = if (dark) Color(0xFFF7F7FF) else Color(0xFF25263A)
    val keySubText = if (dark) Color(0xFFF0F0FA) else Color(0xFF3A3B52)
    val sub = if (digit == '0') "+" else GurmukhiKeys.label(digit).replace(" ", "")
    Box(
        Modifier
            .size(70.dp)
            .shadow(3.dp, KeyShape, clip = false)
            .clip(KeyShape)
            .background(scheme.surfaceVariant)
            .combinedClickable(onClick = { onKey(digit) }, onLongClick = { onLongKey(digit) }),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(digit.toString().toGurmukhiDigits(), fontSize = 26.sp, color = keyText)
            if (sub.isNotEmpty()) {
                Text(sub, fontSize = 11.sp, color = keySubText, maxLines = 1, softWrap = false)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CallRow(hasDigits: Boolean, onCall: () -> Unit, onBackspace: () -> Unit, onClear: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(62.dp)
                    .shadow(6.dp, CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(GradientStart, GradientEnd)))
                    .clickable(onClick = onCall),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Call, contentDescription = "ਕਾਲ", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (hasDigits) 1f else 0.4f))
                    .combinedClickable(onClick = onBackspace, onLongClick = onClear),
                contentAlignment = Alignment.Center,
            ) {
                Text("⌫", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    NavigationBar(
        containerColor = scheme.surface,
        tonalElevation = 0.dp,
        modifier = Modifier.height(72.dp),
    ) {
        TABS.forEachIndexed { i, label ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = {
                    Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                        when (i) {
                            0 -> Icon(Icons.Filled.Star, contentDescription = null, tint = FavoriteOrange, modifier = Modifier.size(20.dp))
                            1 -> ClockIcon()
                            2 -> DialpadIcon()
                            else -> Icon(Icons.Filled.Person, contentDescription = null, modifier = Modifier.size(20.dp))
                        }
                    }
                },
                label = { Text(label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = scheme.primary,
                    selectedTextColor = scheme.primary,
                    indicatorColor = scheme.secondaryContainer,
                    unselectedIconColor = scheme.onSurfaceVariant,
                    unselectedTextColor = scheme.onSurfaceVariant,
                ),
            )
        }
    }
}

@Composable
private fun ClockIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(22.dp)) {
        val stroke = 2.dp.toPx()
        val r = size.minDimension / 2 - stroke
        drawCircle(color, radius = r, style = Stroke(stroke))
        drawLine(color, center, Offset(center.x, center.y - r * 0.55f), stroke, StrokeCap.Round)
        drawLine(color, center, Offset(center.x + r * 0.4f, center.y + r * 0.15f), stroke, StrokeCap.Round)
    }
}

@Composable
private fun DialpadIcon() {
    val color = LocalContentColor.current
    Canvas(Modifier.size(22.dp)) {
        val gap = size.width / 4
        for (row in 1..3) for (col in 1..3) {
            drawCircle(color, radius = 2.dp.toPx(), center = Offset(col * gap, row * gap))
        }
    }
}
