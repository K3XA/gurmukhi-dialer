package com.example.gurmukhidialer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gurmukhidialer.data.RecentCall
import com.example.gurmukhidialer.smartdial.GurmukhiKeys
import com.example.gurmukhidialer.smartdial.Match

private val KEYS = "123456789*0#".toList()
private val TABS = listOf("ਮਨਪਸੰਦ", "ਹਾਲੀਆ", "ਕੀਪੈਡ", "ਸੰਪਰਕ")
private const val KEYPAD = 2

@Composable
fun DialerScreen(vm: DialerViewModel, onCall: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(KEYPAD) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopBrand()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                KEYPAD -> KeypadPage(vm, onCall, onSeeAll = { tab = 1 })
                1 -> RecentPage(vm.recents, onCall)
                else -> ElegantEmptyPage(TABS[tab], if (tab == 0) Icons.Filled.Star else Icons.Filled.Person)
            }
        }
        BottomNav(tab) { tab = it }
    }
}

@Composable
private fun TopBrand() {
    val context = LocalContext.current
    val dark = isAppInDarkTheme()
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("ਸੁਹਾਵਣਾ", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            Text("ਫ਼ੋਨ", fontSize = 28.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
        }
        CircleAction(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode) {
            ThemeController.setDarkOverride(context, !dark)
        }
        Spacer(Modifier.size(8.dp))
        CircleAction(Icons.Filled.Settings) { }
    }
}

@Composable
private fun CircleAction(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .75f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(19.dp)) }
}

@Composable
private fun KeypadPage(vm: DialerViewModel, onCall: (String) -> Unit, onSeeAll: () -> Unit) {
    if (vm.digits.isEmpty()) {
        Column(Modifier.fillMaxSize()) {
            SearchPill()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 6.dp)
                ) {
                    item { SectionTitle("ਤੁਹਾਡੀਆਂ ਹਾਲੀਆ ਕਾਲਾਂ", "ਸਾਰੇ", onSeeAll) }
                    if (vm.recents.isEmpty()) item { EmptyRecents() }
                    else items(vm.recents.take(3), key = { it.number + it.timeMillis }) {
                        RecentCard(it) { onCall(it.number) }
                    }
                }
            }
            Keypad(vm::press) { if (it == '0') vm.press('+') }
            CallControl(false, {}, vm::backspace, vm::clear)
        }
    } else {
        val state = rememberLazyListState()
        LaunchedEffect(vm.results) { state.scrollToItem(0) }
        Column(Modifier.fillMaxSize()) {
            NumberPanel(vm.digits, vm::clear)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (vm.results.isEmpty()) {
                    Text("ਕੋਈ ਸੰਪਰਕ ਨਹੀਂ ਮਿਲਿਆ", color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp), textAlign = TextAlign.Center)
                } else {
                    LazyColumn(Modifier.fillMaxSize(), state = state) {
                        items(vm.results, key = { it.contact.id to it.contact.number }) { m ->
                            ResultCard(m) { onCall(m.contact.number) }
                        }
                    }
                }
            }
            Keypad(vm::press) { if (it == '0') vm.press('+') }
            CallControl(true, { onCall(vm.digits) }, vm::backspace, vm::clear)
        }
    }
}

@Composable
private fun SearchPill() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 15.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(19.dp))
        Text("ਸੰਪਰਕ ਜਾਂ ਨੰਬਰ ਲੱਭੋ", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f).padding(start = 10.dp))
        Box(Modifier.size(30.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha=.11f)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Add, "ਨਵਾਂ ਸੰਪਰਕ", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
        Text(action, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable(onClick = onClick))
    }
}

private val AvatarColors = listOf(Color(0xFF0B8061), Color(0xFF7759B7), Color(0xFFB46A26), Color(0xFF2C7597), Color(0xFFAD4E6E))

@Composable
private fun RecentCard(r: RecentCall, onClick: () -> Unit) {
    val label = r.name?.takeIf { it.isNotBlank() } ?: r.number
    val idx = (label.hashCode() and Int.MAX_VALUE) % AvatarColors.size
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(43.dp).clip(CircleShape).background(AvatarColors[idx]), contentAlignment = Alignment.Center) {
            Text(label.take(1), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).padding(start = 13.dp)) {
            Text(if (label == r.number) label.toGurmukhiDigits() else label, fontSize = 14.sp,
                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(timeAgoGurmukhi(r.timeMillis), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha=.1f)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Call, "ਕਾਲ", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        }
        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun EmptyRecents() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp)
        .clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).padding(vertical = 25.dp),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha=.1f)),
                contentAlignment = Alignment.Center) { Icon(Icons.Filled.Call, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.height(10.dp))
            Text("ਹਾਲੇ ਕੋਈ ਹਾਲੀਆ ਕਾਲ ਨਹੀਂ", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("ਤੁਹਾਡੀਆਂ ਕਾਲਾਂ ਇੱਥੇ ਦਿਖਣਗੀਆਂ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RecentPage(recents: List<RecentCall>, onCall: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { SectionTitle("ਹਾਲੀਆ", "", {}) }
        if (recents.isEmpty()) item { EmptyRecents() }
        else items(recents, key = { it.number + it.timeMillis }) { RecentCard(it) { onCall(it.number) } }
    }
}

@Composable
private fun NumberPanel(number: String, clear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 5.dp)
        .clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 17.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(number.toGurmukhiDigits(), fontSize = 31.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center)
        Text("×", fontSize = 23.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.clickable(onClick = clear).padding(4.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Keypad(onKey: (Char) -> Unit, onLongKey: (Char) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { d ->
                    Box(
                        Modifier.size(66.dp).shadow(2.dp, RoundedCornerShape(22.dp), clip=false)
                            .clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface)
                            .combinedClickable(onClick={onKey(d)}, onLongClick={ {onLongKey(d)} }),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.toString().toGurmukhiDigits(), fontSize = 24.sp, fontWeight = FontWeight.Medium)
                            val sub = if (d == '0') "+" else GurmukhiKeys.label(d).replace(" ", "")
                            if (sub.isNotEmpty()) Text(sub, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines=1)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CallControl(enabled: Boolean, onCall: () -> Unit, back: () -> Unit, clear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(Modifier.size(64.dp).shadow(10.dp, CircleShape, clip=false).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF18A876), Color(0xFF087353))))
                .clickable(enabled=enabled, onClick=onCall), contentAlignment=Alignment.Center) {
                Icon(Icons.Filled.Call, "ਕਾਲ", tint=Color.White, modifier=Modifier.size(26.dp))
            }
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(Modifier.size(44.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=if(enabled) 1f else .35f))
                .combinedClickable(onClick=back, onLongClick=clear), contentAlignment=Alignment.Center) {
                Text("⌫", fontSize=20.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ResultCard(m: Match, onClick: () -> Unit) {
    val name = m.contact.name
    val accent = MaterialTheme.colorScheme.primary
    val annotated = buildAnnotatedString {
        val h=m.highlight
        if(h==null) append(name) else {
            val s=h.first.coerceIn(0,name.length); val e=(h.last+1).coerceIn(s,name.length)
            append(name.substring(0,s))
            withStyle(SpanStyle(color=accent,fontWeight=FontWeight.Bold)){append(name.substring(s,e))}
            append(name.substring(e))
        }
    }
    Row(Modifier.fillMaxWidth().padding(horizontal=22.dp,vertical=4.dp).clip(RoundedCornerShape(18.dp))
        .background(MaterialTheme.colorScheme.surface).clickable(onClick=onClick).padding(12.dp),
        verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),contentAlignment=Alignment.Center){
            Text(name.take(1), color=MaterialTheme.colorScheme.onPrimaryContainer, fontWeight=FontWeight.Bold)
        }
        Column(Modifier.padding(start=13.dp)) {
            Text(annotated,fontSize=14.sp,color=MaterialTheme.colorScheme.onSurface)
            Text(m.contact.number.toGurmukhiDigits(),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ElegantEmptyPage(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment=Alignment.Center) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
            .background(MaterialTheme.colorScheme.surface).padding(vertical=40.dp,horizontal=24.dp),
            horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.size(66.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha=.1f)),
                contentAlignment=Alignment.Center){Icon(icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(28.dp))}
            Spacer(Modifier.height(14.dp))
            Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold)
            Text("ਤੁਹਾਡੀ ਜਾਣਕਾਰੀ ਇੱਥੇ ਸੁੰਦਰ ਢੰਗ ਨਾਲ ਦਿਖਾਈ ਜਾਵੇਗੀ",fontSize=12.sp,
                color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=TextAlign.Center,modifier=Modifier.padding(top=6.dp))
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant.copy(alpha=.55f))
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface, tonalElevation=0.dp, modifier=Modifier.height(76.dp)) {
        TABS.forEachIndexed { i,label ->
            NavigationBarItem(selected=selected==i,onClick={onSelect(i)},icon={
                when(i){
                    0->Icon(Icons.Filled.Star,null,modifier=Modifier.size(19.dp))
                    1->ClockIcon()
                    2->DialpadIcon()
                    else->Icon(Icons.Filled.Person,null,modifier=Modifier.size(19.dp))
                }
            },label={Text(label,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(
                selectedIconColor=MaterialTheme.colorScheme.primary,selectedTextColor=MaterialTheme.colorScheme.primary,
                indicatorColor=MaterialTheme.colorScheme.primary.copy(alpha=.1f),
                unselectedIconColor=MaterialTheme.colorScheme.onSurfaceVariant,unselectedTextColor=MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable private fun ClockIcon(){
    val c=LocalContentColor.current
    Canvas(Modifier.size(21.dp)){val s=2.dp.toPx();val r=size.minDimension/2-s;drawCircle(c,r,style=Stroke(s));drawLine(c,center,Offset(center.x,center.y-r*.55f),s,StrokeCap.Round);drawLine(c,center,Offset(center.x+r*.4f,center.y+r*.15f),s,StrokeCap.Round)}
}
@Composable private fun DialpadIcon(){
    val c=LocalContentColor.current
    Canvas(Modifier.size(21.dp)){val g=size.width/4;for(y in 1..3)for(x in 1..3)drawCircle(c,2.dp.toPx(),Offset(x*g,y*g))}
}
